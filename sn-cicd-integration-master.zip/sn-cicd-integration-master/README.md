# CICD Server Component

[CICD V3](https://github.com/bmoers/sn-cicd/tree/release/3) needs this Update-Set to be installed to work.

To convert this to run under your company namespace run
```
gulp namespace --name your-name-space
```

Please note: the namespace must also be set in the CICD_APP_PREFIX env variable (in .env in the sn-cicd project)